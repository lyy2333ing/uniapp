## 1.0.0（2021-11-19）
- 优化 组件UI，并提供设计资源，详见:[https://uniapp.dcloud.io/component/uniui/resource](https://uniapp.dcloud.io/component/uniui/resource)
- 文档迁移，详见:[https://uniapp.dcloud.io/component/uniui/uni-dateformat](https://uniapp.dcloud.io/component/uniui/uni-dateformat)
## 0.0.5（2021-07-08）
- 调整 默认时间不再是当前时间，而是显示'-'字符
## 0.0.4（2021-05-12）
- 新增 组件示例地址
## 0.0.3（2021-02-04）
- 调整为uni_modules目录规范
- 修复 iOS 平台日期格式化出错的问题
