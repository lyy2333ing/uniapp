<template>
	<!--template:定义当前页面的结构 相当于 wxml -->
	<view class="hot-container">
		<!-- 微信小程序的 image 组件-->
		<image class="logo" src="@/static/images/logo.png" mode="aspectFit"/>
		<!-- 可直接使用组件，无需注册 -->
		<view class="search-box">
			<my-search placeholderText="uni-app 自定义组件"></my-search>
		</view>
	</view>
</template>

<script>
import {getHotTabs} from 'api/hot' ;
// script:定义当前页面的逻辑 相当于js
	export default {
		data() {
			return {};
		},
		/**
		 * created:组件实现配置完成，但 DOM 未渲染，进行网络请求，配置响应式数据
		 */
		created() {
		  this.loadHotTbas();
		},
		/**
		 * 所有的方法必须被定义到 methods 中
		 */
		methods:{
			/** 
			 * 获取 热搜文章类型
			 */
			async loadHotTbas(){
				const res = await getHotTabs();
				console.log(res);
			}
		}
	}
</script>

<style lang="scss" scoped>
// scoped 表示当前文件的样式只在当前组件中生效 样式的隔离性
// style:定义当前页面的样式 相当于 wxss
.hot-container{
	background-color:#fff;
	.logo { 
	  width: 100%;
	  height: 80px;
	}
	.search-box{
		padding:0 16px;
		margin-bottom: 8px;
	}
}
</style>
