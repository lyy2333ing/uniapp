<template>
<!-- 
	1.具备输入框的样式
	2.不可输入
	3.placeholder 内容可以在父组件定义
-->
	<view class="my-search-container">
	  <!-- 搜索按钮 -->
	  <view class="my-search-box">
		<!-- 搜索图标 -->
		<image class="icon" src="@/static/images/search.png" mode=""></image>
		<!-- placeholder-->
		<text class="placeholder">{{ placeholderText }}</text>
	  </view>
	</view>
</template>

<script>
	export default {
		name:"my-search",
		// properties
		props:{
		  placeholderText:{
			type:String,
			default:'搜索'
		  }
		},
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss" scoped>
.my-search-container{
  display:flex;
  align-items: center;
  .my-search-box{
	height:36px;
	width: 100%;
	background-color: #fff;
	border-radius:15px;
	border:1px solid #c9c9c9;
	display: flex;
	align-items: center;
	padding: 0 10px;

	.icon{
		width:$uni-spacing-sm;
		height:$uni-spacing-sm;
	}
	.placeholder{
		font-size: 12px;
		margin-left: 5px;
		color: #999;
	}
  }
}

</style>