<template>
	<!--
		my-tabs 是一个通用的组件
		1. 可以在父组件中定制样式
		2. 可以在父组件中指定数据
		3. 可以在父组件中选中项
	-->
	<view> </view>
</template>

<script>
	export default {
		name:"my-tabs",
		props:{
			// 1.在父组件中定制样式
			// 配置对象
			config:{
				type:Object,
				// default 如果是复杂数据类型，那么需要指定 value 为一个函数，通过 返回值的形式执行默认值
				default:()=>{
					return {};
				}
			},
			// 2.在父组件中指定数据
			tabData:{
				type: Array,
				default:()=>{
					return [];
				}
			},
			// 3.在父组件中选中项
			defaultIndex:{
				type:Number,
				default:0
			}

		},
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss" scoped>
.tab-container {
	font-size:14px;
	height:45px;
	line-height:45px;
	background-color: #ffffff;
	.tab-box{
		width:100%;
		height:45px;
		display: flex;
		position:relative;
		.scroll-view {
		  white-space: nowrap;
		  width:100%;
		  height: 100%;
		  box-sizing: border-box;
		  .scroll-content {
			width: 100%;
			height: 100%;
			position: relative;
			.tab-item-box{
				height: 100%;
				.tab-item{
				  height:100%;
				  display: inline-block;
				  text-align: center;
				  padding:0 15px;
				  position:relative;
				  color:#333;
				  
				}
			}
		  }
		}
	}
}

</style>